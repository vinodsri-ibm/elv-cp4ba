# Elevance Health PoX: Claims Sweep Intake

Automate the claims sweep for IBM Consulting at Elevance.

IBM-C is using a manual process to handle Claims Sweep Intake. An Excel spreadsheet file is downloaded from CIW.

* Macro 1 is run to create DCNs for a query to Teradata.
* Teradata query is run and added
* Macro 2
* Macro 3
* Macro 4 is run to create the pivot table

[IBM-C provided Excel Macros](./data/All%205-VisualBasicScript.txt)

* Test Cases
  * [Phase 1](./testCases/testCasePhase1.md)
  * [Phase 2](./testCases/testCasePhase2.md)
  * [Phase 3](./testCases/testCasePhase3.md)
  * [Phase 4](./testCases/testCasePhase4.md)

## Jupyter Notebooks

* [Setting Up Python & Jupyter Notebooks on macOS](./notebooks/pythonSetup.md)
* [Jupyter Notebook Visual Studio Code Setup](./vscodeSetup.md)

## BAW Java Extensons

* [Setting Up Java on macOS](./BAW_Extension/javaSetup.md)
* [Create Projects For Macros](./BAW_Extension/javaProjects.md)
