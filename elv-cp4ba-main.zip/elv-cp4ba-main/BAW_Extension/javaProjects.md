# Create Projects For Macros

1. Maven will be used to create the project structure

   ```sh
   mvn archetype:generate -DgroupId=com.ibm.baw.custom -DartifactId=macro1 -DarchetypeArtifactId=maven-archetype-quickstart -DinteractiveMode=false

   mvn archetype:generate -DgroupId=com.ibm.baw.custom -DartifactId=macro2 -DarchetypeArtifactId=maven-archetype-quickstart -DinteractiveMode=false

   mvn archetype:generate -DgroupId=com.ibm.baw.custom -DartifactId=macro3 -DarchetypeArtifactId=maven-archetype-quickstart -DinteractiveMode=false

   mvn archetype:generate -DgroupId=com.ibm.baw.custom -DartifactId=macro4 -DarchetypeArtifactId=maven-archetype-quickstart -DinteractiveMode=false
   ```

2. Go into the top level folder in each of the projects and set the JDK to use

   ```sh
   cd macro1
   jenv local 1.8

   cd ../macro2
   jenv local 1.8

   cd ../macro3
   jenv local 1.8

   cd ../macro4
   jenv local 1.8
   ```

3. The Jave code is developed normally. The JUnit test is used to test the functionality.The POM needs to be modified to add the appropriate dependencies. The following Maven commands are used to create the Jar file that will be imported into CP4BA BAW.

   ```sh
   mvn clean initialize package
   ```
