# Setting Up Java on macOS

The following components will be installed on MacOS:

* _jenv_: to manage multiple Java installations on your machine, allowing different Java versions for various projects.
* IBM Semeru Open Runtime Edition 8.0.442 JDK

## Installation of the IBM Semeru Open Runtime Edition JDK

1. With a web browser, go to the [IBM Semeru Open Runtime Edition download](https://developer.ibm.com/languages/java/semeru-runtimes/downloads/?os=undefined) page. Set the filters for _Java 8 (LTS) and _Operating System: macOS_.

2. Download the _8.0.442.0_ package.

3. Run the Installer. Make note of the installation path of the JDK: _/Library/Java/JavaVirtualMachines/ibm-semeru-open-8.jdk_

## Installation of _jenv_

1. Install _jenv_.

   ```sh
   brew update
   brew install jenv  
   ```

2. Update Z shell to use _jenv_.

   ```sh
   echo 'export PATH="$HOME/.jenv/bin:$PATH"' >> ~/.zshrc
   echo 'eval "$(jenv init -)"' >> ~/.zshrc
   ```

3. Restart the shell, then enable the _export_ plugin

   ```sh
   eval "$(jenv init -)"
   jenv enable-plugin export
   ```

4. Restart the shell and verify _jenv_ was installed correctly by running `jenv doctor`.

   ```sh
   jenv doctor
   [OK]      No JAVA_HOME set
   [ERROR]  Java binary in path is not in the jenv shims.
   [ERROR]  Please check your path, or try using `jenv add /path/to/java/home`
   PATH :   /Users/user/.jenv/libexec:/Users/user/.jenv/shims:/Users/user/.jenv/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin
   [OK]     Jenv is correctly loaded
   ```

5. Add the IBM Semeru Open 8 JDK to _jenv_.

   ```sh
   jenv add /Library/Java/JavaVirtualMachines/ibm-semeru-open-8.jdk/Contents/Home
   ```

6. Verify the JDK was added to _jenv_.

   ```sh
   jenv versions
   * system (set by /Users/user/.jenv/version)
   1.8
   1.8.0.442
   semeru64-1.8.0.442
   ```
