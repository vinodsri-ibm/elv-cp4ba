package com.ibm.baw.custom;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for Macro4.
 */
public class Macro4Test 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public Macro4Test( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( Macro4Test.class );
    }

    /**
     * Rigourous Test
     */
    public void testMacro4()
    {
        try {
            Macro4 macro4 = new Macro4();

            //assertNull(macro4.pivot("/Users/dcavanau/git/elv-cp4ba/data/SP-918447_Sweep.xlsx"));
            assertNull(macro4.pivot("/Users/dcavanau/git/elv-cp4ba/data/SP-918447_SweepDPC.xlsx", 
            "/Users/dcavanau/git/elv-cp4ba/data/SP-918447_SweepDPC.xlsx"));
        }
        catch(Exception e) {
            fail("Should not have thrown any exception: " + e.getMessage());
        }
    }
}