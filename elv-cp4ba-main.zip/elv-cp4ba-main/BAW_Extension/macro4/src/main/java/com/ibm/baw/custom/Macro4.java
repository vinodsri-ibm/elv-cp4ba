package com.ibm.baw.custom;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.*;
import org.apache.poi.xssf.usermodel.*;


public class Macro4 
{
	private final static Logger logger = Logger.getLogger("com.ibm.baw.custom.Macro4");

    public Macro4()
    {

    }

    public Void pivot(String workbookName, String workbookDestination)
    {
        try 
        {
            /* open the workbook */
            FileInputStream input_document = new FileInputStream(new File(workbookName));
            XSSFWorkbook workbook = new XSSFWorkbook(input_document);
			logger.logp(Level.INFO, "com.ibm.bpm.custom.Macro4", "pivot", "Retrieved workbook: " + workbookName);

            /* rename worksheet Sheet1 to Master Data */
            XSSFSheet sheet = workbook.getSheet("Sheet1");
            workbook.setSheetName(workbook.getSheetIndex(sheet), "MasterData");
			logger.logp(Level.INFO, "com.ibm.bpm.custom.Macro4", "pivot", "Renamed Sheet1 to MasterData");

            /* determine if the Pivot worksheet already exists */
            XSSFSheet pivot_sheet;
            int pivotSheetIndex = workbook.getSheetIndex("Pivot");
            if (pivotSheetIndex >= 0) {
                workbook.removeSheetAt(pivotSheetIndex);
                logger.logp(Level.INFO, "com.ibm.bpm.custom.Macro4", "pivot", "Deleted existing Pivot worksheet");
            }
            pivot_sheet=workbook.createSheet("Pivot");
        	logger.logp(Level.INFO, "com.ibm.bpm.custom.Macro4", "pivot", "Created Pivot worksheet");
            
            /* Get the reference for Pivot Data */
            int firstRow = sheet.getFirstRowNum();
            int lastRow = sheet.getLastRowNum();
            int firstCol = sheet.getRow(0).getFirstCellNum();
            int lastCol = sheet.getRow(0).getLastCellNum();
            CellReference topLeft = new CellReference(firstRow, firstCol);
            CellReference botRight = new CellReference(lastRow, lastCol - 1);
            AreaReference source = new AreaReference(topLeft, botRight,SpreadsheetVersion.EXCEL2007);
			logger.logp(Level.INFO, "com.ibm.bpm.custom.Macro4", "pivot", "Set area reference for pivot table");

            /* Find out where the Pivot Table needs to be placed */
            CellReference position=new CellReference("A3");

            /* get a list of column names */
            int colDCN=0, colAnalysis = 0, colReason = 0, colPayDesc = 0;
            Row headerRow = sheet.getRow(0);
            for(int cellNum = 0; cellNum < headerRow.getLastCellNum(); cellNum++) {
                switch(headerRow.getCell(cellNum).getStringCellValue()) {
                    case "DCMNT_CNTRL" :
                       colDCN = cellNum;

                    case "IT_Analysis" :
                       colAnalysis = cellNum;

                    case "Reason for incl/excl":
                       colReason = cellNum;

                    case "PAY_DESC":
                       colPayDesc = cellNum;
                }
            }

            /* Create Pivot Table on worksheet Pivot */
            XSSFPivotTable pivotTable = pivot_sheet.createPivotTable(source,position,sheet);
            logger.logp(Level.INFO, "com.ibm.bpm.custom.Macro4", "pivot", "Create pivot table");
            pivotTable.addColumnLabel(DataConsolidateFunction.COUNT, colDCN);
            pivotTable.addRowLabel(colAnalysis);
            pivotTable.addRowLabel(colReason);
            pivotTable.addRowLabel(colPayDesc);

            /* create the bar chart */


            /* Update the workbook */
            input_document.close();
            FileOutputStream output_document = new FileOutputStream(new File(workbookDestination));
            workbook.write(output_document);
            workbook.close();
            output_document.close();
    
        } catch(IOException e) 
        {
			logger.logp(Level.OFF, "com.ibm.bpm.custom.Macro4", "pivot", "error accessing Excel file", e);
        } finally
        {

        }
        return null;
    }

}
