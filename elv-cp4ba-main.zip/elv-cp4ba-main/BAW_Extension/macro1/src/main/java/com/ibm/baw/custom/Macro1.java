package com.ibm.baw.custom;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.*;
import org.apache.poi.xssf.usermodel.*;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTAutoFilter;

public class Macro1 
{
    private final static Logger logger = Logger.getLogger("com.ibm.baw.custom.Macro1");

    public static void main( String[] args )
    {
    }

    public void execute(String workbookName, String workbookDestination)
    {
        try {
            /* open the workbook */
            FileInputStream input_document = new FileInputStream(new File(workbookName));
            XSSFWorkbook workbook = new XSSFWorkbook(input_document);
			logger.logp(Level.INFO, "com.ibm.bpm.custom.Macro1", "execute", "Retrieved workbook: " + workbookName);

            /* load Sheet2 or Data */
            XSSFSheet data_sheet;
            int dataSheetIndex = workbook.getSheetIndex("Sheet2");
            if (dataSheetIndex >= 0) {
                workbook.getSheetAt(dataSheetIndex);
                logger.logp(Level.INFO, "com.ibm.bpm.custom.Macro1", "execute", "Opened worksheet Sheet2");
            } else {
                workbook.getSheet("Data");
                logger.logp(Level.INFO, "com.ibm.bpm.custom.Macro1", "execute", "Opened worksheet Data");
            }

            /* Get the column indicies that will need filtering */
            int colStatus=0, colAnalysis = 0, colReason = 0, colPayDesc = 0;
            Row headerRow = data_sheet.getRow(0);
            for(int cellNum = 0; cellNum < headerRow.getLastCellNum(); cellNum++) {
                switch(headerRow.getCell(cellNum).getStringCellValue()) {
                    case "Status" :
                        colStatus = cellNum;
            
                    case "IT_Analysis" :
                        colAnalysis = cellNum;
            
                    case "Reason for incl/excl":
                        colReason = cellNum;
            
                    case "PAY_DESC":
                        colPayDesc = cellNum;
                    }
            }
            /* Filter value 'Remaining' from column Status */
            int firstRow = data_sheet.getFirstRowNum();
            int lastRow = data_sheet.getLastRowNum();
            int firstCol = data_sheet.getRow(0).getFirstCellNum();
            int lastCol = data_sheet.getRow(0).getLastCellNum();
            CellReference topLeft = new CellReference(firstRow, firstCol);
            CellReference botRight = new CellReference(lastRow, lastCol - 1);
            AreaReference source = new AreaReference(topLeft, botRight,SpreadsheetVersion.EXCEL2007);
            logger.logp(Level.INFO, "com.ibm.bpm.custom.Macro4", "pivot", "Set area reference for pivot table");
            
        } catch(IOException e) 
        {
			logger.logp(Level.OFF, "com.ibm.bpm.custom.Macro1", "pivot", "error accessing Excel file", e);
        } finally
        {

        }
        return null;
    }

     private static void setCriteriaFilter(XSSFSheet sheet, int colId, int firstRow, int lastRow, String[] criteria) throws Exception {
  CTAutoFilter ctAutoFilter = sheet.getCTWorksheet().getAutoFilter();
  CTFilterColumn ctFilterColumn = null;
  for (CTFilterColumn filterColumn : ctAutoFilter.getFilterColumnList()) {
   if (filterColumn.getColId() == colId) ctFilterColumn = filterColumn;
  }
  if (ctFilterColumn == null) ctFilterColumn = ctAutoFilter.addNewFilterColumn();
  ctFilterColumn.setColId(colId);
  if (ctFilterColumn.isSetFilters()) ctFilterColumn.unsetFilters();

  CTFilters ctFilters = ctFilterColumn.addNewFilters();
  for (int i = 0; i < criteria.length; i++) {
   ctFilters.addNewFilter().setVal(criteria[i]);
  }

  //hiding the rows not matching the criterias
  DataFormatter dataformatter = new DataFormatter();
  for (int r = firstRow; r <= lastRow; r++) {
   XSSFRow row = sheet.getRow(r);
   boolean hidden = true;
   for (int i = 0; i < criteria.length; i++) {
    String cellValue = dataformatter.formatCellValue(row.getCell(colId));
    if (criteria[i].equals(cellValue)) hidden = false;
   }
   if (hidden) {
    row.getCTRow().setHidden(hidden);
   } else {
    if (row.getCTRow().getHidden()) row.getCTRow().unsetHidden();
   }
  }
 }


}
