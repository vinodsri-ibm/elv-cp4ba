# Phase 1 Test Cases

| Test Case | Description | Test Criteria |
| --------- | ----------- | ------------- |
| PH01.01 | workbook without sheet _Sheet2_ and _Data_ | **ValueException** |
| PH01.02 | workbook with sheet _Sheet2_ | _Data_ selected |
| PH01.03 | workbook without sheet _Data_ | _Sheet2_ selected |
| PH01.04 | workbook with sheet _Sheet2_ and _Data_ | _Sheet2_ selected |
| PH01.1x0 | Count number of rows in _Status_ colums with value of _REMAINING_ | Total number of rows |
| PH01.20 | column _SYSTEM_NAME_ exists | Test Case PH01.24 |
| PH01.21 | column _SYSTEM_NAME_ doesn't exists | Test Case PH01.27 |
