# Jupyter Notebook Visual Studio Code Setup

This requires VSCode to already be installed and open.

## Install the required extensions

1. Select the _Extensions_ view and search for the _Jupyter_ extension.  Click _Install_ to install this extension.

2. Select the _Extensions_ view and search for the _Python_ extension.  Click _Install_ to install this extension.

## Create or open a Jupyter Notebook

You can create a Jupyter Notebook by running the **Create: New Jupyter Notebook** command from the Command Palette (`⇧⌘P`) or by creating a new `.ipynb` file in your workspace.

Next, select a kernel using the kernel picker in the top right. You will want to select the **jupyter_env**.
