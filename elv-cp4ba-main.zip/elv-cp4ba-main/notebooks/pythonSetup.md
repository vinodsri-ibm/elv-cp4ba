# Setting Up Python & Jupyter Notebooks on macOS

The following components will be installed on MacOS:

* _Pyenv_: to manage multiple Python installations on your machine, allowing different Python versions for various projects.
* _Virtualenv_: to create isolated environments for your Python projects, ensuring independent installations of packages and dependencies.
* _Jupyter Notebook_: an interactive computing environment that enables you to create and share documents containing live code, visualizations, explanatory text, and more.

## Installation of Python Environment

The installation process uses the HomeBrew package manager for installing the components.

1. Install the necessicary dependencies:

   ```sh
   brew update
   brew install pyenv
   brew install pyenv-virtualenv
   brew install npm  # JupyterLab requires npm
   ```

2. Update Z shell to use _pyenv_.

   ```sh
   echo 'export PYENV_ROOT="$HOME/.pyenv"' >> ~/.zshrc
   echo 'command -v pyenv >/dev/null || export PATH="$PYENV_ROOT/bin:$PATH"' >> ~/.zshrc
   echo 'eval "$(pyenv init -)"' >> ~/.zshrc
   echo 'if which pyenv-virtualenv-init > /dev/null; then eval "$(pyenv virtualenv-init -)"; fi' >> ~/.zshrc
   ```

3. Open a new shell to apply the updates and install Python 3.

   ```sh
   pyenv install 3
   pyenv global 3
   ```

4. Create a Python 3 virtual environment for Jupyter Notebooks.

   ```sh
   pyenv virtualenv 3 jupyter_env
   pyenv activate jupyter_env
   ```

5. View the virtual environments by running:

   ```sh
   pyenv virtualenvs
   ```

6. Install Jupyter Notebook in the new environment

   ```sh
   pip3 install jupyterlab
   jupyter lab build
   ```

7. Add pandas and openpyxl libraries

```sh
pip3 install pandas
pip3 install openpyxl
```
